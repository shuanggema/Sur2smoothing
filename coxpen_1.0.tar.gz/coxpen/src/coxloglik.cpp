#include <RcppArmadillo.h>
using namespace Rcpp;


// [[Rcpp::depends(RcppArmadillo)]]

// [[Rcpp::plugins(cpp11)]]

// [[Rcpp::export]]

List cox_log(arma::vec y,  arma::vec delta, arma::mat X, arma::vec beta){
  int n = y.size();
  int m = X.n_cols;
  arma::vec eta = X*beta;
  double logLik = 0;
  arma::rowvec grad(m);
  grad.zeros();
  arma::mat H(m,m);
  H.zeros();
  arma::rowvec Wx(m), Xv(m), S(m);
  arma::vec w = arma::exp(eta);
  arma::mat Wx2(m,m), XtX;
  Wx.zeros();
  Wx2.zeros();
  double W  =0 ;
  
  for (int i=n-1; i>=0; i--){
    Xv = X.row(i);
    
    W = W + w(i);
    Wx = Wx + Xv*w(i);
    S = Wx/W;
    
    Wx2 = Wx2 + (Xv.t() * Xv) * w(i);
    
    if (delta[i] !=0){
      logLik = logLik + eta(i) - log(W);
      grad = grad + Xv- Wx/W;
      H = H - Wx2/W + S.t()*S ;
    }
  }
  List res = List::create(Named("logLik")=  logLik, _["gradient"] = grad, _["hessian"] = H);
  return res;
}
